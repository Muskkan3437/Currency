import requests
import tkinter as tk
from tkinter import ttk

# create the Tkinter Screen
Screen = tk.Tk()
Screen.title("Muskan Money Exchanger")

# set the Screen size and background color
Screen.geometry("500x400")
Screen.configure(bg="#F8F8FF")

# get the currency exchange Price from the internet
Get_Api = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
Price = Get_Api.json()['rates']

# create the available currencies list
available_currencies = list(Price.keys())

# create the input widgets
Lbl1_Amt = ttk.Label(Screen, text="Enter amount:", font=("Helvetica", 14, "bold"), foreground="#333", background="#F8F8FF")
Lbl1_Amt.place(x=50, y=70)
Get_Amnt = ttk.Entry(Screen, font=("Helvetica", 12), foreground="#333")
Get_Amnt.place(x=200, y=70, width=250)

Currency1 = ttk.Label(Screen, text="From:", font=("Helvetica", 14, "bold"), foreground="#333", background="#F8F8FF")
Currency1.place(x=50, y=130)
Menu1 = ttk.Combobox(Screen, values=available_currencies, state="readonly", font=("Helvetica", 12), foreground="#333")
Menu1.place(x=200, y=130, width=250)

Currency2 = ttk.Label(Screen, text="To:", font=("Helvetica", 14, "bold"), foreground="#333", background="#F8F8FF")
Currency2.place(x=50, y=190)
Menu2 = ttk.Combobox(Screen, values=available_currencies, state="readonly", font=("Helvetica", 12), foreground="#333")
Menu2.place(x=200, y=190, width=250)

Result = ttk.Label(Screen, text="", font=("Helvetica", 14, "bold"), foreground="#333", background="#F8F8FF")
Result.place(x=50, y=300, width=400, height=40)

# create the conversion function
def convert_currency():
    # get the input values
    amount = float(Get_Amnt.get())
    FromCurrency = Menu1.get()
    ToCurrency = Menu2.get()

    # convert the currency
    result = amount * Price[ToCurrency] / Price[FromCurrency]

    # update the result label
    Result.configure(text=f"{amount:.2f} {FromCurrency} is equal to {result:.2f} {ToCurrency}")

# create the conversion button
convert_button = ttk.Button(Screen, text="Convert", command=convert_currency)
convert_button.place(x=200, y=240, width=250, height=40)

# create the reset button
def reset():
    Get_Amnt.delete(0, 'end')
    Menu1.set('')
    Menu2.set('')
    Result.configure(text='')

reset_button = ttk.Button(Screen, text="Reset", command=reset)
reset_button.place(x=50, y=240, width=120, height=40)

# run the Tkinter event loop
Screen.mainloop()
